package com.emergentes.modelo;
public class Permisos {
   private int id;
   private int id_usuarios;
   private int id_rol;

    public Permisos() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId_usuarios() {
        return id_usuarios;
    }

    public void setId_usuarios(int id_usuarios) {
        this.id_usuarios = id_usuarios;
    }

    public int getId_rol() {
        return id_rol;
    }

    public void setId_rol(int id_rol) {
        this.id_rol = id_rol;
    }

    @Override
    public String toString() {
        return "Permisos{" + "id=" + id + ", id_usuarios=" + id_usuarios + ", id_rol=" + id_rol + '}';
    }
}
