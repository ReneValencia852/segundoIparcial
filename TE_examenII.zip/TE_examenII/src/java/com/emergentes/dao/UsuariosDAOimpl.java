package com.emergentes.dao;
import com.emergentes.modelo.Usuarios;
import com.emergentes.utiles.conexionDB;
import java.sql.PreparedStatement;
import java.util.List;

public class UsuariosDAOimpl extends conexionDB implements UsuariosDAO{

    @Override
    public void insert(Usuarios usuarios) throws Exception {
        try {
        this.conectar();
        PreparedStatement ps = this.conn.prepareStatement("INSERT INTO usuarios(usuario, correo, clave)value (?,?,?)");
        ps.setString(1,usuarios.getNombre());
        ps.setString(2,usuarios.getCorreo());
        ps.setString(3,usuarios.getClave());
        ps.executeUpdate();
        } catch(Exception e){
            throw e;
        } finally{
            this.desconectar();
        }
    }

    @Override
    public void update(Usuarios usuarios) throws Exception {
       
    }

    @Override
    public void delete(int id) throws Exception {
        try {
        this.conectar();
        PreparedStatement ps = this.conn.prepareStatement("UPDATE Usuarios SET usuario = ?, correo = ?, clave = ? where id = ?");
        ps.setString(1,usuario.getNombre());
        ps.setString(2,usuario.getCorreo());
        ps.setString(3,usuario.getClave());
        ps.executeUpdate();
        } catch(Exception e){
            throw e;
        } finally{
            this.desconectar();
        }
    }

    @Override
    public Usuarios getById(int Id) throws Exception {
       
    }

    @Override
    public List<Usuarios> getAll() throws Exception {
        
    }
    
}
